import rospy

def move_to_kitchen():
    rospy.wait_for_service('/go_to_kitchen')
    try:
        go_to_kitchen = rospy.ServiceProxy('/go_to_kitchen', Empty)
        go_to_kitchen()
        rospy.loginfo("Moved to kitchen.")
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

def stop_movement():
    rospy.wait_for_service('/stop')
    try:
        stop = rospy.ServiceProxy('/stop', Empty)
        stop()
        rospy.loginfo("Movement stopped.")
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

def move_to_home():
    rospy.wait_for_service('/go_home')
    try:
        go_home = rospy.ServiceProxy('/go_home', Empty)
        go_home()
        rospy.loginfo("Returned to home.")
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

if __name__ == '__main__':
    rospy.init_node('robot_controller')
    move_to_kitchen()
    stop_movement()
    move_to_home()
    stop_movement()
